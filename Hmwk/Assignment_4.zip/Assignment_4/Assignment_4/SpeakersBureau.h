/* 
 * File:   SpeakersBureau.h
 * Author: Victor Alcaraz
 * Created on October 8, 2015, 12:50 PM
 */

#ifndef SPEAKERSBUREAU_H
#define	SPEAKERSBUREAU_H

struct Speaker{
    string name;
    string phone;
    string topic;
    float fee;
};

#endif	/* SPEAKERSBUREAU_H */

