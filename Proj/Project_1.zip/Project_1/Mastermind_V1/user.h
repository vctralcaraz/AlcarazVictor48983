/* 
 * File:   user.h
 * Author: Victor Alcaraz
 * Created on October 20, 2015, 1:09 PM
 * Purpose: usernames
 */

#ifndef USER_H
#define	USER_H

using namespace std;

struct User{
    string name;
};

#endif	/* USER_H */