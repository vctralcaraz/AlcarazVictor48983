/* 
 * File:   SaveData.h
 * Author: rcc
 *
 * Created on October 7, 2015, 2:50 PM
 */

#ifndef SAVEDATA_H
#define	SAVEDATA_H

struct Save{
    int *data;  //array with data information {games,wins,loses,average,win 
                                            // with least amount of tries}
};

#endif	/* SAVEDATA_H */

